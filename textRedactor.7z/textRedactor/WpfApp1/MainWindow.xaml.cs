﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            FileInfo fl = new FileInfo($"{AppDomain.CurrentDomain.BaseDirectory}data\\{Vars.a}.txt");
            
            if(Vars.a != null )RightText.Text = $"{DateTime.Now} размер{fl.Length}";
        }
        Boolean bold = false;
        Boolean kurs = false;
        Boolean underline = false;
        Boolean save = false;

        private void TextKeyDownEvent(object sender, KeyEventArgs k)
        {
            
            if (k.Key != null) RightText.Text = $"{DateTime.Now} размер{new FileInfo($"{AppDomain.CurrentDomain.BaseDirectory}data\\{Vars.a}.txt").Length/1024}";
            if (k.Key == Key.Tab)
            {
                txtbox.AppendText("\t");
            }
            if(k.Key == Key.Enter)
            {
                txtbox.AppendText("\n");
            }
            
            if (k.Key == Key.LeftShift && list_files.Items.Contains(Vars.a) == false) list_files.Items.Add(Vars.a);
            if(Mouse.LeftButton == Mouse.LeftButton)
            {
                int row = txtbox.GetLineIndexFromCharacterIndex(txtbox.CaretIndex);
                int col = txtbox.CaretIndex - txtbox.GetLineIndexFromCharacterIndex(row);
                if (save == false)
                {
                    LeftText.Text = $"строка: {row + 1} столбец: {col + 1} Требуется сохранение";
                    save = true;
                }
                else if(save == true) LeftText.Text = $"строка: {row + 1} столбец: {col + 1} Не требуется сохранение";
            }
        }

        private void New(object sender, RoutedEventArgs e)
        {
            NewFile NewFileWindow = new NewFile();
            
            if (NewFileWindow.ShowDialog() == false)
            {

                list_files.Items.Add(Vars.a);
            }

        }
        private void SaveFile(object sender, RoutedEventArgs e)
        {
           
            StreamWriter sw = new StreamWriter($"{AppDomain.CurrentDomain.BaseDirectory}data\\{Vars.a}.txt");
            sw.Write(txtbox.Text);
            sw.Close();
            
        }
       private void DeleteFile(object sender, RoutedEventArgs e)
        {
            File.Delete(Vars.a);
            list_files.Items.Remove(Vars.a);
            txtbox.Clear();
        }
        private void Kursiv(object sender, RoutedEventArgs e)
        {
            if (kurs == false)
            {
                txtbox.FontStyle = FontStyles.Italic;
                kurs = true;
            }
            else
            {
                txtbox.FontStyle = FontStyles.Normal;
                kurs = false;
            }
        }
        private void Bold_(object sender, RoutedEventArgs e)
        {
            if (bold == false)
            {
                txtbox.FontWeight = FontWeights.Bold;
                bold = true;
            }
            else
            {
                txtbox.FontWeight = FontWeights.Normal;
                bold = false;
            }
        }
        private void Podcherk_(object sender, RoutedEventArgs e)
        {
            if (underline == false)
            {
                txtbox.TextDecorations = TextDecorations.Underline;
                underline = true;
            }
            else
            {
                txtbox.TextDecorations = TextDecorations.Baseline;
                underline = false;
            }
        }
      
    }
}
